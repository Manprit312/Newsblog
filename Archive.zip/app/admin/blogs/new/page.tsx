import BlogForm from '@/components/BlogForm';

export default function NewBlogPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold text-secondary-blue mb-6">Create New Blog</h1>
      <BlogForm />
    </div>
  );
}











